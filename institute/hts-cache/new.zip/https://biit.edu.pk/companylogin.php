<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Company Login/Register Modal</title>
  <title>Barani Institute of Information Technology</title>

  <!-- Canonical URL -->
  <link rel="canonical" href="https://www.biit.edu.pk/">

  <!-- Favicon -->
  <link rel="icon" href="https://biit.edu.pk/assets/img/about/BIIT_logo.webp" type="image/x-icon">
  <link rel="apple-touch-icon" href="assets/img/about/BIIT_logo.png" />

  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/animate.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/inpage-style.css?v=1.0">
  <link rel="stylesheet" href="assets/css/responsive.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin-top: 100;
      padding: 0;
    }
    .main {
      height: 100%;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    /* Modal Container */
    .modal {
      position: relative;
      z-index: 1;
      left: 0;
      top: 0;
      margin-top: 150px;
      width: 100vw;
      height: fit-content;
      overflow: auto;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .modal-content {
      background: #fff;
      padding: 30px 20px 20px 20px;
      border-radius: 10px;
      width: 100%;
      max-width: 400px;
      position: relative;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    }

    .close {
      position: absolute;
      right: 20px;
      top: 10px;
      font-size: 28px;
      color: #0c7347;
      cursor: pointer;
    }

    .modal-tabs {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }

    .tab-btn {
      background: none;
      border: none;
      font-size: 18px;
      font-weight: 600;
      color: #0c7347;
      padding: 10px 20px;
      cursor: pointer;
      border-bottom: 2px solid transparent;
      transition: border 0.2s;
    }

    .tab-btn.active {
      border-bottom: 2px solid #0c7347;
    }

    .tab-content {
      margin-top: 10px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      color: #0c7347;
    }

    .form-control {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    .job-fair-button {
      background-color: #0c7347;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      font-weight: 600;
      width: 100%;
      transition: background 0.3s;
    }

    .job-fair-button:hover {
      background-color: #095d36;
    }

    .modal-icon {
      width: 28px;
      height: 28px;
      margin-right: 8px;
      vertical-align: middle;
      filter: invert(21%) sepia(99%) saturate(749%) hue-rotate(101deg) brightness(97%) contrast(101%);
    }

    h3 {
      display: flex;
      align-items: center;
      color: #0c7347;
      margin-bottom: 15px;
    }

    a.switch-to-login {
      color: #0c7347;
      text-decoration: none;
      font-weight: 600;
    }

    a.switch-to-login:hover {
      text-decoration: underline;
    }

    .img {
      position: absolute;
      top: 100;
      z-index: -100;
      height: 160%;
      width: 100%;
    }
  </style>
</head>
<body>
  <div class="preloader">
    <div class="loader"></div>
  </div>
  <div class="fixed-navbar new-navbar">
            <html lang="en">

        <head>
            <meta property="og:title" content="Barani Institute of Information Technology (BIIT) - Rawalpindi">
            <meta property="og:description" content="Barani Institute of Information Technology (BIIT), affiliated with Arid Agriculture University, offers the BSCS (General Computing), BSCS (Artificial Intelligence), and BSSE programs. Located in Rawalpindi, BIIT is dedicated to providing quality education in the field of computer science and software engineering.">
            <meta property="og:type" content="website">
            <meta property="og:url" content="https://www.biit.edu.pk">
            <meta property="og:image" content="https://biit.edu.pk/assets/img/about/BIIT_logo.png">
            <script>
                ! function(f, b, e, v, n, t, s) {
                    if (f.fbq) return;
                    n = f.fbq = function() {
                        n.callMethod ?
                            n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                    };
                    if (!f._fbq) f._fbq = n;
                    n.push = n;
                    n.loaded = !0;
                    n.version = '2.0';
                    n.queue = [];
                    t = b.createElement(e);
                    t.async = !0;
                    t.src = v;
                    s = b.getElementsByTagName(e)[0];
                    s.parentNode.insertBefore(t, s)
                }(window, document, 'script',
                    'https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', '2389046301230263');
                fbq('track', 'PageView');
            </script>
            <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2389046301230263&ev=PageView&noscript=1" /></noscript>
            <style>
                /* Improved Dropdown Menu Styles */
                .dropdown-menu {
                    display: none;
                    position: absolute;
                    z-index: 1000;
                    background-color: #F3F6FB;
                    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
                    border-radius: 8px;
                    padding: 10px 0;
                    min-width: 220px;
                    border: none;
                }

                /* Show dropdown on hover for desktop */
                @media (min-width: 992px) {
                    .menu-item.dropdown:hover .dropdown-menu {
                        display: block;
                    }
                }

                .dropdown-menu.show {
                    display: block !important;
                }

                .dropdown-item {
                    display: block;
                    padding: 8px 20px;
                    color: #0c7347;
                    font-size: 16px;
                    font-weight: 500;
                    text-decoration: none;
                    transition: all 0.3s ease;
                    margin: 5px 10px;
                    border-radius: 5px;
                }

                .dropdown-item:hover,
                .dropdown-item:focus {
                    background-color: rgba(12, 115, 71, 0.1);
                    color: #0c7347;
                }

                .dropdown-item.active {
                    background-color: rgba(12, 115, 71, 0.2);
                    font-weight: 600;
                }

                /* Main Menu Item */
                .menu-item a {
                    font-size: 18px;
                    color: #0c7347 !important;
                    font-weight: 600;
                    padding: 10px 15px;
                    transition: all 0.3s ease;
                    text-decoration: none;
                }

                .menu-item a:hover {
                    background-color: rgba(12, 115, 71, 0.1);
                    border-radius: 8px;
                    color: #0c7347;
                }

                .dropdown-toggle::after {
                    margin-left: 8px;
                }

                /* Responsive Styles */
                @media (max-width: 991px) {
                    .dropdown-menu {
                        position: static;
                        box-shadow: none;
                        background-color: transparent;
                        /* padding-left: 20px; */
                    }

                    .dropdown-item {
                        padding: 8px 15px;
                        margin: 2px 0;
                    }

                    .menu-item a {
                        font-size: 18px;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                    }

                    .enhanced-logo {
                        margin-left: -10px !important;
                    }
                }

                @media (max-width: 991px) {
                    .navbar-collapse {
                        max-height: 88vh;
                        overflow-y: auto;
                        overflow-x: hidden;
                    }
                    .menu-item a {
                        font-size: 15px;
                         padding: 8px 0px !important;
                    }
                }
                  @media (max-width: 1200px) {
                     
                    .menu-item a {
                        font-size: 14px !important;
                         padding: 8px 5px !important;
                    }
                }

                /* Demo styles */
                .navbar-area {
                    background-color: #F3F6FB !important;
                }

                .container {
                    max-width: 1200px;
                }

                .navbar {
                    padding: 15px 0;
                }

                .menu-open {
                    gap: 18px;
                }

                .btn-base {
                    background-color: #0c7347;
                    color: white;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 10px;
                    text-decoration: none;
                }

                .btn-base:hover {
                    background-color: #095d39;
                    color: white;
                }
                .logo{
                    margin-left:20px;
                }
            </style>

        </head>

        <body>

            <div >
                <nav class="navbar navbar-area navbar-expand-lg bg-gray box-shadow-2" style="background-color:#F3F6FB !important;">

                    <img class="navbar-shape" src="assets/img/about/0.png" alt="img" style="height: 140px; width:470px; margin-left:-80px">
                    <div class="container nav-container custom-container">
                        <div class="responsive-mobile-menu">
                            <button class="menu toggle-btn d-block d-lg-none" data-target="#navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="margin-right: 0px; margin-top:35px !important;">
                                <span class="icon-left"></span>
                                <span class="icon-right"></span>
                            </button>
                        </div>
                        <div class="logo">
                            <a href="index"><img src="assets/img/about/Colored Logo.png" alt="img" class="enhanced-logo" style="height: 80px; width:450px;margin-top:20px"></a>
                        </div>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav menu-open ps-lg-8 ms-xl-7 d-flex align-items-center justify-content-center mx-auto" style="gap: 3px;">
                                <div class="menu-item">
                                    <a id="menu-home" href="index" class="text-sm">Home</a>
                                </div>
                                <div class="menu-item">
                                    <a id="menu-about" href="About-Us" class="text-sm">About Us</a>
                                </div>
                                <div class="menu-item dropdown">
                                    <a href="#" class="dropdown-toggle nav-link" id="programsDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 18px ">
                                        Admissions
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="programsDropdown">
                                        <a href="admission#admission-form" class="dropdown-item">Admission Form</a>
                                        <a href="admission#eligibility" class="dropdown-item">Eligibility Criteria</a>
                                        <a href="admission#fee-structure" class="dropdown-item">Fee Structure</a>
                                        <a href="admission#migration" class="dropdown-item">Migration / Transfer of Students</a>
                                        <a href="admission#scholarship" class="dropdown-item">Financial Aid / Scholarships</a>
                                        <a href="admission#foreign-applicants" class="dropdown-item">Foreign Applicants</a>
                                        <a href="admission#rules" class="dropdown-item">Rules and Regulations</a>
                                        <a href="admission#faqs" class="dropdown-item">Admission FAQ's</a>

                                    </ul>
                                </div>
                               

                                <div class="menu-item">
                                    <a id="menu-admission" href="Contact-Us" class="text-sm">Contact Us</a>
                                </div>
                                <!-- <div class="menu-item">
                            <a id="menu-program" href="degree" class="text-sm">Programs</a>
                        </div> -->
                                <!-- 'Programs' dropdown only for larger screens -->
                                <!-- <div class="menu-item dropdown more-item" style="position: relative;">
                            <a href="#" class="text-sm dropdown-toggle" id="infoDropdown" role="button" aria-expanded="false">Programs</a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="infoDropdown" style="position: absolute; left: 50%; transform: translateX(-50%); height: auto ">
                                <a href="degree#GC" class="dropdown-item" style="font-size: 18px;">BSCS (General Computing)</a>
                                <a href="degree#AI" class="dropdown-item" style="font-size: 18px;">BSCS (Artificial Intelligence)</a>
                                <a href="degree#SE" class="dropdown-item" style="font-size: 18px;">BS Software Engineering</a>
                                <a href="adp-degree#ADP-AI" class="dropdown-item" style="font-size: 18px;">ADP (Artificial Intelligence)</a>
                                <a href="adp-degree#ADP-WD" class="dropdown-item" style="font-size: 18px;">ADP CS (Web Development)</a>
                                <a href="adp-degree#ADP-MAD" class="dropdown-item" style="font-size: 18px;">ADP CS (Mobile App Development)</a>
                            </ul>
                        </div> -->

                                <!-- Single dropdown implementation -->
                                <div class="menu-item dropdown">
                                    <a href="#" class="dropdown-toggle nav-link" id="programsDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 18px  ">
                                        Programs
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="programsDropdown">
                                        <a href="adp-degree#ADP-AI" class="dropdown-item">ADP (Artificial Intelligence)</a>
                                        <a href="adp-degree#ADP-MAD" class="dropdown-item">ADP CS (Mobile App Development)</a>
                                        <a href="adp-degree#ADP-WD" class="dropdown-item">ADP CS (Web Development)</a>
                                        <a href="degree#BET-I" class="dropdown-item">BET (I)</a>
                                        <a href="degree#AI" class="dropdown-item">BSCS (Artificial Intelligence)</a>
                                        <a href="degree#GC" class="dropdown-item">BSCS (General Computing)</a>
                                        <a href="degree#SE" class="dropdown-item">BS Software Engineering</a>
                                    </ul>
                                </div>


                                <!-- 'More' items as regular menu items for smaller screens -->
                                <!-- <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">BSCS (General Computing)</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">BSCS (Artificial Intelligence)</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">BS Software Engineering</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">ADP (AI)</a>
                        </div>

                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">ADP (Web Development)</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">ADP (Mobile App Development)</a>
                        </div> -->

                                <!-- 'More' dropdown only for larger screens -->
                                <!-- <div class="menu-item dropdown more-item" style="position: relative;">
                                <a href="#" class="text-sm dropdown-toggle" id="infoDropdown" role="button" aria-expanded="false">More</a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="infoDropdown" style="position: absolute; left: 50%; transform: translateX(-50%); height: auto;">
                                    <a href="Team" class="dropdown-item" style="font-size: 18px;">Team</a>
                                    <a href="QEC" class="dropdown-item" style="font-size: 18px;">QEC</a>
                                    <a href="CSO" class="dropdown-item" style="font-size: 18px;">Career Services</a>
                                    <a href="Society" class="dropdown-item" style="font-size: 18px;">Societies</a>
                                    <a href="News" class="dropdown-item" style="font-size: 18px;">News</a>
                                    <a href="Download" class="dropdown-item" style="font-size: 18px;">Downloads</a>
                                </ul>
                            </div> -->

                                <div class="menu-item dropdown">
                                    <a href="#" class="dropdown-toggle" id="infoDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        More
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="infoDropdown">
                                        <a href="CSO" class="dropdown-item" style="font-size: 18px;">Career Services</a>
                                        <a href="Download" class="dropdown-item" style="font-size: 18px;">Downloads</a>
                                        <a href="News" class="dropdown-item" style="font-size: 18px;">News</a>
                                        <a href="QEC" class="dropdown-item" style="font-size: 18px;">QEC</a>
                                        <a href="Society" class="dropdown-item" style="font-size: 18px;">Societies</a>
                                        <a href="Team" class="dropdown-item" style="font-size: 18px;">Team</a>
                                    </ul>
                                </div>
                                <!-- 'More' items as regular menu items for smaller screens -->
                                <!-- <div class="menu-item d-lg-none">
                                <a href="Team" class="text-sm">Team</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="QEC" class="text-sm">QEC</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="CSO" class="text-sm">Career Services</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="Society" class="text-sm">Societies</a>
                            </div>

                            <div class="menu-item d-lg-none">
                                <a href="News" class="text-sm">News</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="Download" class="text-sm">Downloads</a>
                            </div> -->
                                <!-- <div class="menu-item d-lg-none " style="display: none;">
                        <a href="sc" class="text-sm"></a>
                    </div> -->


                            </ul>

                            <div class="text-center" style=" ">
                                <a class="btn btn-base mt-0 border-radius-10 apply-now-btn" target="_blank" href="https://admission.biit.edu.pk/" onclick="handleClick()">Apply Now</a>
                                <!--<a class="btn btn-base mt-0 border-radius-10 apply-now-btn" href="javascript:void(0)" >Apply Now</a>-->

                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <!-- <div id="popup" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; background-color: #fff; padding: 25px; border-radius: 15px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15); max-width: 400px; width: 100%;">
    <p style="font-size: 18px; line-height: 1.6; font-family: Arial, sans-serif; text-align: center; color: #333;">
        <strong>Admissions at BIIT are Closed Now!</strong><br><br>
        Admissions are open at our associated <br/>university, Northern University.<br> To apply, please visit: 
        <a href="https://admissions.northern.edu.pk" target="_blank" style="color: #0c7347; text-decoration: none;">admissions.northern.edu.pk</a>
    </p>
    <button onclick="closePopup()" style="margin-top: 20px; padding: 8px 16px; background-color: #0c7347; color: #fff; border: none; border-radius: 5px; display: block; width: 100%; cursor: pointer; font-size: 16px;">Close</button>
</div> -->

            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>

            <script src="assets/js/main.js"></script>


            <script>
                $(document).ready(function() {
                    var currentPath = window.location.pathname.split('/').pop(); // Get the current page

                    // Add 'active' class to the current menu item
                    $('.menu-item a').each(function() {
                        var menuItemPath = $(this).attr('href'); // Get the href attribute of the link

                        if (currentPath === menuItemPath || (currentPath === '' && menuItemPath === 'index')) { // Handle the home link case
                            $(this).addClass('active');

                            if ($(this).hasClass('dropdown-item')) {
                                $(this).closest('.dropdown').find('.dropdown-toggle').addClass('active');
                            }
                        }
                    });
                });
            </script>
            <script>
                function showPopup() {
                    document.getElementById('popup').style.display = 'block';
                }

                function closePopup() {
                    document.getElementById('popup').style.display = 'none';
                }
            </script>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Get all dropdown toggle elements
                    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');

                    dropdownToggles.forEach(toggle => {
                        const dropdownMenu = toggle.nextElementSibling;

                        // Handle click events
                        toggle.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();

                            // Check if this dropdown is currently open
                            const isCurrentlyOpen = dropdownMenu.classList.contains('show');

                            // Close all dropdowns first
                            document.querySelectorAll('.dropdown-menu.show').forEach(openMenu => {
                                openMenu.classList.remove('show');
                            });

                            // Reset all toggle aria-expanded attributes
                            document.querySelectorAll('.dropdown-toggle').forEach(otherToggle => {
                                otherToggle.setAttribute('aria-expanded', 'false');
                            });

                            // If the clicked dropdown wasn't open, open it
                            if (!isCurrentlyOpen) {
                                dropdownMenu.classList.add('show');
                                toggle.setAttribute('aria-expanded', 'true');
                            }
                        });
                    });

                    // Close dropdowns when clicking outside
                    document.addEventListener('click', function(e) {
                        // Check if the click was outside any dropdown
                        if (!e.target.closest('.dropdown')) {
                            document.querySelectorAll('.dropdown-menu.show').forEach(openMenu => {
                                openMenu.classList.remove('show');
                            });
                            document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
                                toggle.setAttribute('aria-expanded', 'false');
                            });
                        }
                    });

                    // Prevent dropdown menu clicks from closing the dropdown
                    document.querySelectorAll('.dropdown-menu').forEach(menu => {
                        menu.addEventListener('click', function(e) {
                            e.stopPropagation();
                        });
                    });

                    // Handle active menu highlighting
                    var currentPath = window.location.pathname.split('/').pop();

                    document.querySelectorAll('.menu-item a').forEach(function(link) {
                        var menuItemPath = link.getAttribute('href');

                        if (currentPath === menuItemPath || (currentPath === '' && menuItemPath === 'index')) {
                            link.classList.add('active');

                            if (link.classList.contains('dropdown-item')) {
                                link.closest('.dropdown').querySelector('.dropdown-toggle').classList.add('active');
                            }
                        }
                    });
                });

                function handleClick() {
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "increment_clicks.php", true);
                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xhr.send();
                }
            </script>
        </body>

        </html>  </div>
  <div class="main">
    <img class="img" src="assets/img/banner-2/BIIT banner.webp" alt="Background Image">

    <div id="companyModal" class="modal">
      <div class="modal-content">
        <!-- Tabs -->
        <div class="modal-tabs">
          <button class="tab-btn active" id="companyLoginTab">Login</button>
          <button class="tab-btn" id="companyRegisterTab">Register</button>
        </div>

        <!-- LOGIN FORM -->
        <div id="companyLoginForm" class="tab-content">
          <h3>
            <img src="assets/icons/company.svg" alt="Company Icon" class="modal-icon">
            Sign In as Company
          </h3>
          <form action="job_fair_login.php" method="POST">
            <input type="hidden" name="form_type" value="company">
            <div class="form-group">
              <label for="company-login-email" style="color:black;">Email Address</label>
              <input type="email" id="company-login-email" name="login_id" class="form-control" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
              <label for="company-login-password" style="color:black;">Password</label>
              <input type="password" id="company-login-password" name="login_password" class="form-control" placeholder="Enter your password" required minlength="6">
            </div>
            <button type="submit" class="job-fair-button">Login</button>
          </form>
        </div>

        <!-- REGISTER FORM -->
        <div id="companyRegisterForm" class="tab-content" style="display:none;">
          <h3>
            <img src="assets/icons/company.svg" alt="Company Icon" class="modal-icon">
            Sign Up as Company
          </h3>
          <form action="assets/company_operations.php" method="POST">
            <div class="form-group">
              <label for="company-register-name" style="color:black;">Company Name</label>
              <input type="text" id="company-register-name" name="company-register-name" class="form-control" placeholder="Enter company name" required>
            </div>
            <div class="form-group">
              <label for="company-register-email" style="color:black;">Email</label>
              <input type="email" id="company-register-email" name="company-register-email" class="form-control" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
              <label for="company-register-password" style="color:black;">Password</label>
              <input type="password" id="company-register-password" name="company-register-password" class="form-control" placeholder="Enter password" required minlength="6">
            </div>
            <div class="form-group">
              <label for="company-register-confirm-password" style="color:black;">Confirm Password</label>
              <input type="password" id="company-register-confirm-password" name="company-register-confirm-password" class="form-control" placeholder="Confirm password" required minlength="6">
            </div>
            <button type="submit" class="job-fair-button">Register</button>
          </form>
          <p style="margin-top:10px; text-align:center;">
            Already have an account?
            <a href="#" id="company-switch-login" class="switch-to-login">Sign in here</a>
          </p>
        </div>
      </div>
    </div>
  </div>

  <style>
    @media (max-width: 991px) {
        .row>* {
            justify-content: center;
            flex-shrink: 0;
            width: 100%;
            max-width: 100%;
            padding-right: calc(var(--bs-gutter-x)* .5);
            padding-left: calc(var(--bs-gutter-x)* .5);
            margin-top: var(--bs-gutter-y);
        }

    }


    .widget-recent-post table tbody tr:hover a {
        color: gold;
    }

    .whatsapp-btn {
        color: green;
        background-color: white;
        border-color: green;
        border-radius: 20px;
        min-height: 70px;
        width: 300px;
        transition: background-color 0.3s, color 0.3s;
    }

    .whatsapp-btn:hover {
        background-color: azure;
        color: white;
    }

    .whatsapp-btn img {
        transition: filter 0.3s;
    }

    .white-icon {
        color: white;
    }

    .enhanced-logo img {
        width: 150px;
        height: auto;
    }

    .apply-now-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        font-size: 16px;
        white-space: nowrap;
        min-width: 120px;
        height: 40px;
        line-height: 1;
    }

    .btn:hover,
    .btn-base:hover,
    .bg-base-9:hover {
        color: inherit;
        background-color: inherit;
    }

    @media (max-width: 768px) {
        .whatsapp-btn {
            margin-top: -20px;
            color: green;
            background-color: white;
            border-color: green;
            border-radius: 20px;
            min-height: 70px;
            width: 300px;
            transition: background-color 0.3s, color 0.3s;
        }

        .footer-subscribe .footer-subscribe-inner h2 {
            color: #fff;
            font-size: 25px;
            margin-bottom: -5px;
        }

        .apply-now-btn {
            font-size: 14px;
            padding: 8px 16px;
        }

        .footer-area {
            padding-left: 10px;
            padding-right: 10px;
        }

        .custom-container-footer {
            padding-left: 10px !important;
            padding-right: 10px !important;
        }

        .widget_about .details {
            text-align: center !important;
        }

        .widget_nav_menu {
            text-align: center !important;
        }

        .widget_contact {
            text-align: center !important;
        }

        .whatsapp-btn p {
            font-size: 18px;
            /* Adjust font size for smaller screens */
        }
    }

    .list-unstyled {
        padding: 0;
        list-style: none;
    }

    .list-unstyled li {
        margin-bottom: 10px;
    }

    .list-unstyled li a {
        text-decoration: none;
        color: white;
    }

    .list-unstyled li a:hover {
        color: gold;
    }

    .social-media {
        list-style: none;
        padding: 0;
        display: flex;
        gap: 0px;
    }




    .social-media a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: lightblue;
        transition: transform 0.3s ease, border 0.3s ease;
        border: none;
        /* Ensure no border is shown initially */
        transform: scale(1);
    }

    .social-media a:hover {
        border: 2px solid white;
        /* Avoid padding to keep the icon centered */
        transform: scale(1.2);
        /* Adjust this value to control the growth */
    }
    @media screen and (max-width: 600px) {
        .widget .details{
            height: 80px !important;
        }
        
    }
  
</style>





<footer class="footer-area pt-0 bg-cover pd-top-90" style="background-image: url('./assets/img/bg/footer.png'); width:auto;">
    <div class="footer-subscribe">

    </div>
    <div class="container pt-5 pb-4" >
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="widget widget_about text-center text-md-start">
                    <div class="thumb Logo mb-3">
                        <img src="assets/img/about/BIIT_logo.png" alt="img" style="width: 120px; height: auto;">
                    </div>
                    <div class="details" style="text-align: left;">
                        <ul class="social-media d-flex justify-content-center justify-content-md-start">
                            <li class="me-3">
                                <a class="text-white" href="https://www.facebook.com/BIITOfficial/" target="_blank" style="background-color: #3b5998;">
                                    <i class="fab fa-facebook-f" style="color: white;"></i>
                                </a>
                            </li>

                            <li class="me-3">
                                <a class="text-white" href="https://www.instagram.com/biitofficial/" target="_blank" style="background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); border-radius: 50%; ">
                                    <i class="fab fa-instagram" style="color: white;"></i>
                                </a>
                            </li>

                            <li>
                                <a class="text-white" href="https://www.youtube.com/@biitofficial/" target="_blank" style="background-color: #FF0000; ">
                                    <i class="fab fa-youtube" style="color: white;"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="widget widget_nav_menu text-center text-md-start">
                    <h3 class="widget-title" style="text-align: left; margin-top:10px;">All Links</h3>

                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="About-Us"><i style="color: white;" class="fas fa-arrow-right me-1"></i> About us</a></li>
                        <li class="mb-2"><a href="admission"><i style="color: white;" class="fas fa-arrow-right me-1"></i> Admissions</a></li>
                        <li class="mb-2"><a href="degree"><i style="color: white;" class="fas fa-arrow-right me-1"></i> Academic Programs</a></li>
                        <li><a href="Contact-Us"><i style="color: white;" class="fas fa-arrow-right me-1"></i> Contact us</a></li>

                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="widget widget-recent-post text-center text-md-start">
                    <h3 class="widget-title" style="text-align: left; margin-top:10px;">Contact Info</h3>
                    <table style="border-collapse: collapse; width: 100%; border:none; margin-top:-8px">
                        <tbody>
                            <tr>
                                <td style="border: none; padding: 8px;">
                                    <i style="color: white;" class="fas fa-map-marker-alt"></i>
                                </td>
                                <td style="color: white; border: none; padding: 8px; text-align:left">
                                    <a href="https://www.google.com/maps/search/?api=1&query=106-A%2F1+Murree+Rd%2C+Block+A+Satellite+Town+Rawalpindi%2C+Pakistan" target="_blank" style="color: white; text-decoration: none;"
                                        onmouseover="this.style.color='gold';"
                                        onmouseout="this.style.color='white';">
                                        106-A/1 Murree Rd, Block A Satellite Town Rawalpindi, Pakistan
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none; padding: 8px;">
                                    <i style="color: white; margin-right: 8px;" class="fas fa-phone-alt"></i>
                                </td>
                                <td style="color: white; border: none; padding: 8px;text-align:left">
                                    <a href="tel:+923360572652" style="color: white; text-decoration: none;"
                                        onmouseover="this.style.color='gold';"
                                        onmouseout="this.style.color='white';">
                                        (+92) 336-0572652
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none; padding: 8px;">
                                    <i style="color: white; margin-right: 8px;" class="fas fa-envelope"></i>
                                </td>
                                <td style="color: white; border: none; padding: 8px;text-align:left">
                                    <a href="mailto:admissions@biit.edu.pk" style="color: white; text-decoration: none;"
                                        onmouseover="this.style.color='gold';"
                                        onmouseout="this.style.color='white';">
                                        admissions@biit.edu.pk
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</footer>


<script>
document.addEventListener("DOMContentLoaded", function () {
  const imgs = document.querySelectorAll("img");

  imgs.forEach(img => {
    // Handle data-src and data-srcset first (for lazy-loaded images)
    ['src', 'data-src'].forEach(attr => {
      let src = img.getAttribute(attr);
      if (src && src.includes(".")) {
        let newSrc = src.replace(/(\.[a-zA-Z0-9]+)(\?.*)?$/, ".webp$2");
        img.setAttribute(attr, newSrc);
      }
    });

    ['srcset', 'data-srcset'].forEach(attr => {
      let srcset = img.getAttribute(attr);
      if (srcset) {
        let newSrcset = srcset.replace(/(\.[a-zA-Z0-9]+)(\s|,|$)/g, ".webp$2");
        img.setAttribute(attr, newSrcset);
      }
    });
  });
});
</script>
<script>
window.addEventListener("load", function () {
  document.querySelectorAll("img").forEach(img => {
    let src = img.getAttribute("src");
    if (src && src.includes(".") && !src.endsWith(".webp")) {
      let newSrc = src.replace(/(\.[a-zA-Z0-9]+)(\?.*)?$/, ".webp$2");
      img.setAttribute("src", newSrc);
      console.log("Converted:", newSrc);
    }
  });
});
</script>



<script src="assets/js/fontawesome.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/main.js"></script>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/main.js"></script>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const loginTab = document.getElementById("companyLoginTab");
      const registerTab = document.getElementById("companyRegisterTab");
      const loginForm = document.getElementById("companyLoginForm");
      const registerForm = document.getElementById("companyRegisterForm");
      const switchToLogin = document.getElementById("company-switch-login");

      loginTab.classList.add("active");
      loginForm.style.display = "block";
      registerForm.style.display = "none";

      registerTab.addEventListener("click", function () {
        registerTab.classList.add("active");
        loginTab.classList.remove("active");
        registerForm.style.display = "block";
        loginForm.style.display = "none";
      });

      loginTab.addEventListener("click", function () {
        loginTab.classList.add("active");
        registerTab.classList.remove("active");
        loginForm.style.display = "block";
        registerForm.style.display = "none";
      });

      if (switchToLogin) {
        switchToLogin.addEventListener("click", function (e) {
          e.preventDefault();
          loginTab.classList.add("active");
          registerTab.classList.remove("active");
          loginForm.style.display = "block";
          registerForm.style.display = "none";
        });
      }
    });
  </script>
</body>
</html>
