<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Barani Institute of Information Technology (BIIT) - Premier IT Education in Pakistan</title>

    <meta name="description" content="Barani Institute of Information Technology (BIIT) offers BS Computer Science, AI, and Software Engineering programs. Join Pakistan's leading IT institute for quality education.">
    <meta name="keywords" content="Barani Institute of Information Technology, BIIT, computer science Pakistan, IT education, software engineering, artificial intelligence, BS programs, university in Pakistan, PMAS Arid Agriculture University">


    <!-- Canonical URL -->
    <link rel="canonical" href="https://www.biit.edu.pk/">

    <!-- Open Graph -->
    <meta property="og:title" content="Barani Institute of Information Technology (BIIT)">
    <meta property="og:description" content="Premier IT education institute offering BS Computer Science, AI, and Software Engineering programs in Pakistan.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.biit.edu.pk/">
    <meta property="og:image" content="https://biit.edu.pk/assets/img/about/BIIT_logo.webp">
    <meta property="og:site_name" content="Barani Institute of Information Technology">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Barani Institute of Information Technology (BIIT)">
    <meta name="twitter:description" content="Premier IT education institute in Pakistan offering BS Computer Science, AI, and Software Engineering programs.">
    <meta name="twitter:image" content="https://biit.edu.pk/assets/img/about/BIIT_logo.webp">

    <!-- Favicon -->
    <link rel="icon" href="https://biit.edu.pk/assets/img/about/BIIT_logo.png" type="image/x-icon">
    <!-- Primary Favicon -->
<link rel="icon" type="image/png" sizes="16x16" href="/mnt/data/biit_favicon_pack/favicon_16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="/mnt/data/biit_favicon_pack/favicon_32x32.png">
<link rel="icon" type="image/png" sizes="48x48" href="/mnt/data/biit_favicon_pack/favicon_48x48.png">
<link rel="icon" type="image/png" sizes="64x64" href="/mnt/data/biit_favicon_pack/favicon_64x64.png">
<link rel="icon" type="image/png" sizes="128x128" href="/mnt/data/biit_favicon_pack/favicon_128x128.png">
<link rel="icon" type="image/png" sizes="256x256" href="/mnt/data/biit_favicon_pack/favicon_256x256.png">
<link rel="icon" type="image/png" sizes="512x512" href="/mnt/data/biit_favicon_pack/favicon_512x512.png">

<!-- Apple Touch Icon -->
<link rel="apple-touch-icon" sizes="180x180" href="/mnt/data/biit_favicon_pack/favicon_256x256.png">

<!-- Web App Manifest -->
<link rel="manifest" href="/manifest.json">


    <!-- JSON-LD (Organization Schema) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "EducationalOrganization",
      "name": "Barani Institute of Information Technology",
      "alternateName": "BIIT",
      "url": "https://www.biit.edu.pk/",
      "logo": "https://biit.edu.pk/assets/img/about/BIIT_logo.png",
      "description": "Barani Institute of Information Technology (BIIT) offers BS Computer Science, AI, and Software Engineering programs.",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "PMAS-Arid Agriculture University",
        "addressLocality": "Rawalpindi",
        "addressCountry": "Pakistan"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "contactType": "Admissions",
        "telephone": "+92-336-0572652"
      }
    }
    </script>

    <!-- Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-DM0WFBF03L"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-DM0WFBF03L');
    </script>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/inpage-style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>


    <style>
        .title-h1 {
            font-size: 36px;
            text-align: center;
            margin-top: -70px;
            font-weight: bold;
            line-height: 1.2;
            margin-bottom: 0.67em;
            color: #0c7347;

        }

        .article {
            font-size: 4vw !important;
            /* Fallback for smaller screens */
            color: #0c7347 !important;
        }

        .article a {
            color: #0c7347;
        }

        .page-titles {
            background-image: url('./assets/img/banner-2/BIIT banner.webp');
            margin-top: 70px;
        }

        .page-titles a {
            margin-top: -40px;
        }

        /* Larger screens */
        @media (min-width: 600px) {
            .article {
                color: #0c7347;
                font-size: 20px !important;
            }
        }

        @media (min-width: 768px) {
            .article {
                color: #0c7347 !important;
                font-size: 22px !important;
            }
        }

        @media (min-width: 1024px) {
            .article {
                color: #0c7347 !important;
                font-size: 24px !important;
            }
        }
        @keyframes float {
            0% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-10px);
            }

            100% {
                transform: translateY(0);
            }
        }

        .whatsapp-icon {
            position: fixed;
            right: 20px;
            /* Adjusted for right side */
            bottom: 20px;
            /* Keep the same for vertical positioning */

            border-radius: 50%;
            padding: 10px;
            z-index: 1000;
            /* Ensure it is on top of other content */
            transition: transform 0.3s ease, background-color 0.3s ease;
            /* Transition for hover effect */
            animation: float 3s ease-in-out infinite;
            /* Floating animation */
        }

        .whatsapp-icon img {
            width: 60px;
            /* Adjust the icon size as needed */
            height: auto;
            transition: transform 0.3s ease;
            /* Transition for hover effect */
        }

        /* Hover effect */
        .whatsapp-icon:hover {
            transform: scale(1.2);
            /* Scale the icon slightly on hover */
            /* Optional: Change background color on hover */
        }

        .whatsapp-icon:hover img {
            transform: scale(1.2);
            /* Flip horizontally and zoom in to 120% size on hover */
        }



 @media (max-width: 1200px) {

 .container {
    padding: 10px !important;
 }
        }

        @media (max-width: 768px) {


            .title {
                font-size: 22px !important;
            }

            .bg-yellow {
                margin-top: -50px !important;
            }
        }


        .responsive-img {
            height: 350px;
            width: 230px;
        }

        @media (max-width: 768px) {
            .responsive-img {
                height: 280px;
                width: 184px;
            }
        }

        @media (max-width: 480px) {
            .responsive-img {
                height: 200px;
                width: 131px;
            }
        }

        @media (max-width: 576px) {
            .responsive-div h4 {
                font-size: 1rem;
            }

            .responsive-div ul {
                margin: 0.5rem 0;
                padding: 0.5rem 0;
            }

            .responsive-div ul li {
                margin-bottom: 0.25rem;
            }
        }

        @media (min-width: 577px) and (max-width: 768px) {
            .responsive-div h4 {
                font-size: 1.1rem;
            }

            .responsive-div ul {
                margin: 1rem 0;
                padding: 1rem 0;
            }

            .responsive-div ul li {
                margin-bottom: 0.5rem;
            }
        }

        .white-icon {
            color: white;
        }


        .enhanced-logo img {
            width: 150px;
            height: auto;
        }

        .apply-now-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 20px;
            font-size: 16px;
            white-space: nowrap;
            min-width: 120px;
            height: 40px;
            line-height: 1;
        }

        @media (max-width: 768px) {
            .apply-now-btn {
                font-size: 14px;
                padding: 8px 16px;
            }
        }

        @media (max-width: 768px) {
            .footer-area {
                border: none !important;
                padding-left: 10px !important;
                padding-right: 10px !important;
            }

            .custom-container-footer {
                border: none !important;
                padding-left: 10px !important;
                padding-right: 10px !important;
            }

            .widget_about .details {
                text-align: center !important;
            }

            .widget_nav_menu {
                text-align: center !important;
            }

            .widget_contact {
                text-align: center !important;
            }
        }

        .fixed-navbar {
            border-bottom: 2px solid #0c7347;

            position: fixed;
            top: 0;
            left: 0;
            background-color: white;

            padding: 10px 20px;
            z-index: 1000;
        }

        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            /* Ensure it's above other content */
        }

        .preloader .loader {
            border: 6px solid #f3f3f3;
            /* Light grey */
            border-top: 6px solid #009879;
            /* Blue */
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
        .btn:hover {
            background-color: #0c7347;
            border-color: #0c7347;
            color: white !important;
        }   
    </style>
    <!-- Meta Pixel Code -->

    <!-- End Meta Pixel Code -->
</head>

<body>

    <div class="preloader">
        <div class="loader"></div>
    </div>




    <div class="fixed-navbar new-navbar">
                <html lang="en">

        <head>
            <meta property="og:title" content="Barani Institute of Information Technology (BIIT) - Rawalpindi">
            <meta property="og:description" content="Barani Institute of Information Technology (BIIT), affiliated with Arid Agriculture University, offers the BSCS (General Computing), BSCS (Artificial Intelligence), and BSSE programs. Located in Rawalpindi, BIIT is dedicated to providing quality education in the field of computer science and software engineering.">
            <meta property="og:type" content="website">
            <meta property="og:url" content="https://www.biit.edu.pk">
            <meta property="og:image" content="https://biit.edu.pk/assets/img/about/BIIT_logo.png">
            <script>
                ! function(f, b, e, v, n, t, s) {
                    if (f.fbq) return;
                    n = f.fbq = function() {
                        n.callMethod ?
                            n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                    };
                    if (!f._fbq) f._fbq = n;
                    n.push = n;
                    n.loaded = !0;
                    n.version = '2.0';
                    n.queue = [];
                    t = b.createElement(e);
                    t.async = !0;
                    t.src = v;
                    s = b.getElementsByTagName(e)[0];
                    s.parentNode.insertBefore(t, s)
                }(window, document, 'script',
                    'https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', '2389046301230263');
                fbq('track', 'PageView');
            </script>
            <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2389046301230263&ev=PageView&noscript=1" /></noscript>
            <style>
                /* Improved Dropdown Menu Styles */
                .dropdown-menu {
                    display: none;
                    position: absolute;
                    z-index: 1000;
                    background-color: #F3F6FB;
                    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
                    border-radius: 8px;
                    padding: 10px 0;
                    min-width: 220px;
                    border: none;
                }

                /* Show dropdown on hover for desktop */
                @media (min-width: 992px) {
                    .menu-item.dropdown:hover .dropdown-menu {
                        display: block;
                    }
                }

                .dropdown-menu.show {
                    display: block !important;
                }

                .dropdown-item {
                    display: block;
                    padding: 8px 20px;
                    color: #0c7347;
                    font-size: 16px;
                    font-weight: 500;
                    text-decoration: none;
                    transition: all 0.3s ease;
                    margin: 5px 10px;
                    border-radius: 5px;
                }

                .dropdown-item:hover,
                .dropdown-item:focus {
                    background-color: rgba(12, 115, 71, 0.1);
                    color: #0c7347;
                }

                .dropdown-item.active {
                    background-color: rgba(12, 115, 71, 0.2);
                    font-weight: 600;
                }

                /* Main Menu Item */
                .menu-item a {
                    font-size: 18px;
                    color: #0c7347 !important;
                    font-weight: 600;
                    padding: 10px 15px;
                    transition: all 0.3s ease;
                    text-decoration: none;
                }

                .menu-item a:hover {
                    background-color: rgba(12, 115, 71, 0.1);
                    border-radius: 8px;
                    color: #0c7347;
                }

                .dropdown-toggle::after {
                    margin-left: 8px;
                }

                /* Responsive Styles */
                @media (max-width: 991px) {
                    .dropdown-menu {
                        position: static;
                        box-shadow: none;
                        background-color: transparent;
                        /* padding-left: 20px; */
                    }

                    .dropdown-item {
                        padding: 8px 15px;
                        margin: 2px 0;
                    }

                    .menu-item a {
                        font-size: 18px;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                    }

                    .enhanced-logo {
                        margin-left: -10px !important;
                    }
                }

                @media (max-width: 991px) {
                    .navbar-collapse {
                        max-height: 88vh;
                        overflow-y: auto;
                        overflow-x: hidden;
                    }
                    .menu-item a {
                        font-size: 15px;
                         padding: 8px 0px !important;
                    }
                }
                  @media (max-width: 1200px) {
                     
                    .menu-item a {
                        font-size: 14px !important;
                         padding: 8px 5px !important;
                    }
                }

                /* Demo styles */
                .navbar-area {
                    background-color: #F3F6FB !important;
                }

                .container {
                    max-width: 1200px;
                }

                .navbar {
                    padding: 15px 0;
                }

                .menu-open {
                    gap: 18px;
                }

                .btn-base {
                    background-color: #0c7347;
                    color: white;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 10px;
                    text-decoration: none;
                }

                .btn-base:hover {
                    background-color: #095d39;
                    color: white;
                }
                .logo{
                    margin-left:20px;
                }
            </style>

        </head>

        <body>

            <div >
                <nav class="navbar navbar-area navbar-expand-lg bg-gray box-shadow-2" style="background-color:#F3F6FB !important;">

                    <img class="navbar-shape" src="assets/img/about/0.png" alt="img" style="height: 140px; width:470px; margin-left:-80px">
                    <div class="container nav-container custom-container">
                        <div class="responsive-mobile-menu">
                            <button class="menu toggle-btn d-block d-lg-none" data-target="#navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="margin-right: 0px; margin-top:35px !important;">
                                <span class="icon-left"></span>
                                <span class="icon-right"></span>
                            </button>
                        </div>
                        <div class="logo">
                            <a href="index"><img src="assets/img/about/Colored Logo.png" alt="img" class="enhanced-logo" style="height: 80px; width:450px;margin-top:20px"></a>
                        </div>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav menu-open ps-lg-8 ms-xl-7 d-flex align-items-center justify-content-center mx-auto" style="gap: 3px;">
                                <div class="menu-item">
                                    <a id="menu-home" href="index" class="text-sm">Home</a>
                                </div>
                                <div class="menu-item">
                                    <a id="menu-about" href="About-Us" class="text-sm">About Us</a>
                                </div>
                                <div class="menu-item dropdown">
                                    <a href="#" class="dropdown-toggle nav-link" id="programsDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 18px ">
                                        Admissions
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="programsDropdown">
                                        <a href="admission#admission-form" class="dropdown-item">Admission Form</a>
                                        <a href="admission#eligibility" class="dropdown-item">Eligibility Criteria</a>
                                        <a href="admission#fee-structure" class="dropdown-item">Fee Structure</a>
                                        <a href="admission#migration" class="dropdown-item">Migration / Transfer of Students</a>
                                        <a href="admission#scholarship" class="dropdown-item">Financial Aid / Scholarships</a>
                                        <a href="admission#foreign-applicants" class="dropdown-item">Foreign Applicants</a>
                                        <a href="admission#rules" class="dropdown-item">Rules and Regulations</a>
                                        <a href="admission#faqs" class="dropdown-item">Admission FAQ's</a>

                                    </ul>
                                </div>
                               

                                <div class="menu-item">
                                    <a id="menu-admission" href="Contact-Us" class="text-sm">Contact Us</a>
                                </div>
                                <!-- <div class="menu-item">
                            <a id="menu-program" href="degree" class="text-sm">Programs</a>
                        </div> -->
                                <!-- 'Programs' dropdown only for larger screens -->
                                <!-- <div class="menu-item dropdown more-item" style="position: relative;">
                            <a href="#" class="text-sm dropdown-toggle" id="infoDropdown" role="button" aria-expanded="false">Programs</a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="infoDropdown" style="position: absolute; left: 50%; transform: translateX(-50%); height: auto ">
                                <a href="degree#GC" class="dropdown-item" style="font-size: 18px;">BSCS (General Computing)</a>
                                <a href="degree#AI" class="dropdown-item" style="font-size: 18px;">BSCS (Artificial Intelligence)</a>
                                <a href="degree#SE" class="dropdown-item" style="font-size: 18px;">BS Software Engineering</a>
                                <a href="adp-degree#ADP-AI" class="dropdown-item" style="font-size: 18px;">ADP (Artificial Intelligence)</a>
                                <a href="adp-degree#ADP-WD" class="dropdown-item" style="font-size: 18px;">ADP CS (Web Development)</a>
                                <a href="adp-degree#ADP-MAD" class="dropdown-item" style="font-size: 18px;">ADP CS (Mobile App Development)</a>
                            </ul>
                        </div> -->

                                <!-- Single dropdown implementation -->
                                <div class="menu-item dropdown">
                                    <a href="#" class="dropdown-toggle nav-link" id="programsDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 18px  ">
                                        Programs
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="programsDropdown">
                                        <a href="adp-degree#ADP-AI" class="dropdown-item">ADP (Artificial Intelligence)</a>
                                        <a href="adp-degree#ADP-MAD" class="dropdown-item">ADP CS (Mobile App Development)</a>
                                        <a href="adp-degree#ADP-WD" class="dropdown-item">ADP CS (Web Development)</a>
                                        <a href="degree#BET-I" class="dropdown-item">BET (I)</a>
                                        <a href="degree#AI" class="dropdown-item">BSCS (Artificial Intelligence)</a>
                                        <a href="degree#GC" class="dropdown-item">BSCS (General Computing)</a>
                                        <a href="degree#SE" class="dropdown-item">BS Software Engineering</a>
                                    </ul>
                                </div>


                                <!-- 'More' items as regular menu items for smaller screens -->
                                <!-- <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">BSCS (General Computing)</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">BSCS (Artificial Intelligence)</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">BS Software Engineering</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">ADP (AI)</a>
                        </div>

                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">ADP (Web Development)</a>
                        </div>
                        <div class="menu-item d-lg-none">
                            <a href="degree" class="text-sm">ADP (Mobile App Development)</a>
                        </div> -->

                                <!-- 'More' dropdown only for larger screens -->
                                <!-- <div class="menu-item dropdown more-item" style="position: relative;">
                                <a href="#" class="text-sm dropdown-toggle" id="infoDropdown" role="button" aria-expanded="false">More</a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="infoDropdown" style="position: absolute; left: 50%; transform: translateX(-50%); height: auto;">
                                    <a href="Team" class="dropdown-item" style="font-size: 18px;">Team</a>
                                    <a href="QEC" class="dropdown-item" style="font-size: 18px;">QEC</a>
                                    <a href="CSO" class="dropdown-item" style="font-size: 18px;">Career Services</a>
                                    <a href="Society" class="dropdown-item" style="font-size: 18px;">Societies</a>
                                    <a href="News" class="dropdown-item" style="font-size: 18px;">News</a>
                                    <a href="Download" class="dropdown-item" style="font-size: 18px;">Downloads</a>
                                </ul>
                            </div> -->

                                <div class="menu-item dropdown">
                                    <a href="#" class="dropdown-toggle" id="infoDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        More
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="infoDropdown">
                                        <a href="CSO" class="dropdown-item" style="font-size: 18px;">Career Services</a>
                                        <a href="Download" class="dropdown-item" style="font-size: 18px;">Downloads</a>
                                        <a href="News" class="dropdown-item" style="font-size: 18px;">News</a>
                                        <a href="QEC" class="dropdown-item" style="font-size: 18px;">QEC</a>
                                        <a href="Society" class="dropdown-item" style="font-size: 18px;">Societies</a>
                                        <a href="Team" class="dropdown-item" style="font-size: 18px;">Team</a>
                                    </ul>
                                </div>
                                <!-- 'More' items as regular menu items for smaller screens -->
                                <!-- <div class="menu-item d-lg-none">
                                <a href="Team" class="text-sm">Team</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="QEC" class="text-sm">QEC</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="CSO" class="text-sm">Career Services</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="Society" class="text-sm">Societies</a>
                            </div>

                            <div class="menu-item d-lg-none">
                                <a href="News" class="text-sm">News</a>
                            </div>
                            <div class="menu-item d-lg-none">
                                <a href="Download" class="text-sm">Downloads</a>
                            </div> -->
                                <!-- <div class="menu-item d-lg-none " style="display: none;">
                        <a href="sc" class="text-sm"></a>
                    </div> -->


                            </ul>

                            <div class="text-center" style=" ">
                                <a class="btn btn-base mt-0 border-radius-10 apply-now-btn" target="_blank" href="https://admission.biit.edu.pk/" onclick="handleClick()">Apply Now</a>
                                <!--<a class="btn btn-base mt-0 border-radius-10 apply-now-btn" href="javascript:void(0)" >Apply Now</a>-->

                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <!-- <div id="popup" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; background-color: #fff; padding: 25px; border-radius: 15px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15); max-width: 400px; width: 100%;">
    <p style="font-size: 18px; line-height: 1.6; font-family: Arial, sans-serif; text-align: center; color: #333;">
        <strong>Admissions at BIIT are Closed Now!</strong><br><br>
        Admissions are open at our associated <br/>university, Northern University.<br> To apply, please visit: 
        <a href="https://admissions.northern.edu.pk" target="_blank" style="color: #0c7347; text-decoration: none;">admissions.northern.edu.pk</a>
    </p>
    <button onclick="closePopup()" style="margin-top: 20px; padding: 8px 16px; background-color: #0c7347; color: #fff; border: none; border-radius: 5px; display: block; width: 100%; cursor: pointer; font-size: 16px;">Close</button>
</div> -->

            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>

            <script src="assets/js/main.js"></script>


            <script>
                $(document).ready(function() {
                    var currentPath = window.location.pathname.split('/').pop(); // Get the current page

                    // Add 'active' class to the current menu item
                    $('.menu-item a').each(function() {
                        var menuItemPath = $(this).attr('href'); // Get the href attribute of the link

                        if (currentPath === menuItemPath || (currentPath === '' && menuItemPath === 'index')) { // Handle the home link case
                            $(this).addClass('active');

                            if ($(this).hasClass('dropdown-item')) {
                                $(this).closest('.dropdown').find('.dropdown-toggle').addClass('active');
                            }
                        }
                    });
                });
            </script>
            <script>
                function showPopup() {
                    document.getElementById('popup').style.display = 'block';
                }

                function closePopup() {
                    document.getElementById('popup').style.display = 'none';
                }
            </script>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Get all dropdown toggle elements
                    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');

                    dropdownToggles.forEach(toggle => {
                        const dropdownMenu = toggle.nextElementSibling;

                        // Handle click events
                        toggle.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();

                            // Check if this dropdown is currently open
                            const isCurrentlyOpen = dropdownMenu.classList.contains('show');

                            // Close all dropdowns first
                            document.querySelectorAll('.dropdown-menu.show').forEach(openMenu => {
                                openMenu.classList.remove('show');
                            });

                            // Reset all toggle aria-expanded attributes
                            document.querySelectorAll('.dropdown-toggle').forEach(otherToggle => {
                                otherToggle.setAttribute('aria-expanded', 'false');
                            });

                            // If the clicked dropdown wasn't open, open it
                            if (!isCurrentlyOpen) {
                                dropdownMenu.classList.add('show');
                                toggle.setAttribute('aria-expanded', 'true');
                            }
                        });
                    });

                    // Close dropdowns when clicking outside
                    document.addEventListener('click', function(e) {
                        // Check if the click was outside any dropdown
                        if (!e.target.closest('.dropdown')) {
                            document.querySelectorAll('.dropdown-menu.show').forEach(openMenu => {
                                openMenu.classList.remove('show');
                            });
                            document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
                                toggle.setAttribute('aria-expanded', 'false');
                            });
                        }
                    });

                    // Prevent dropdown menu clicks from closing the dropdown
                    document.querySelectorAll('.dropdown-menu').forEach(menu => {
                        menu.addEventListener('click', function(e) {
                            e.stopPropagation();
                        });
                    });

                    // Handle active menu highlighting
                    var currentPath = window.location.pathname.split('/').pop();

                    document.querySelectorAll('.menu-item a').forEach(function(link) {
                        var menuItemPath = link.getAttribute('href');

                        if (currentPath === menuItemPath || (currentPath === '' && menuItemPath === 'index')) {
                            link.classList.add('active');

                            if (link.classList.contains('dropdown-item')) {
                                link.closest('.dropdown').querySelector('.dropdown-toggle').classList.add('active');
                            }
                        }
                    });
                });

                function handleClick() {
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "increment_clicks.php", true);
                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xhr.send();
                }
            </script>
        </body>

        </html>    </div>




    <!-- page title start -->
    <div class="banner-area bg-relative banner-area-1 banner-area-2 page-titles">
        <img class="banner-shape" src="assets/img/banner-2/H.webp" alt="img">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h6 class="mb-3"></h6>
                    <h2 class="text-white mb-4">Barani Institute <br /> of Information <br /> Technology</h2>
                    <p class="text-white mb-4 pb-3">Empowering Minds, Building Futures<br> Join us in pioneering excellence in technology and innovation </p>
                    <a class="btn btn-yellow" href="Contact-Us">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
    <!-- banner end -->



    <!-- course area start -->
    <div class="course-area pd-top-115 position-relative">
        <div class="container">
            <div class="section-title text-center">

                <h2 class="title-h1 course-heading">Academic Programs</h2>
            </div>
            <div class="row course-areas">
                <div class="col-lg-4 col-md-6">

                    <div class="single-course-inner style-2">
                        <div class="thumb">
                            <img class="w-100" src="assets/img/about/AP1.webp" alt="img">
                            <a class="course-cat fw-500" href="degree?program=AI">BSCS(AI)</a>
                        </div>
                        <div class="details">
                            <div class="row">
                                <div class="col-6">
                                    <div class="course-list">
                                        <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8.5 9.5C11.5312 9.5 14 11.9688 14 15C14 15.5625 13.5312 16 13 16H1C0.4375 16 0 15.5625 0 15C0 11.9688 2.4375 9.5 5.5 9.5H8.5ZM1.5 14.5H12.4688C12.2188 12.5312 10.5312 11 8.5 11H5.5C3.4375 11 1.75 12.5312 1.5 14.5ZM7 8C4.78125 8 3 6.21875 3 4C3 1.8125 4.78125 0 7 0C9.1875 0 11 1.8125 11 4C11 6.21875 9.1875 8 7 8ZM7 1.5C5.59375 1.5 4.5 2.625 4.5 4C4.5 5.40625 5.59375 6.5 7 6.5C8.375 6.5 9.5 5.40625 9.5 4C9.5 2.625 8.375 1.5 7 1.5Z" fill="#2F57EF" />
                                        </svg>
                                        671 Students
                                    </div>
                                </div>
                            </div>
                            <h4 class="course-title mb-4">
                                <a href="degree?program=AI">BS Computer Science <span style="font-size: 0.7em;">with specialization in</span> Artificial Intelligence</a>
                            </h4>

                            <div class="row">
                                <div class="col-6">

                                </div>
                                <div class="col-6 align-self-center text-end">
                                    <a class="right-arrow-text fw-700 color-base" href="degree?program=AI">Enroll Now <i class="fa fa-arrow-right ms-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">

                    <div class="single-course-inner style-2">

                        <div class="thumb">
                            <img class="w-100" src="assets/img/about/AP2.webp" alt="img">
                            <a class="course-cat fw-500" href="degree?program=GC">BSCS(GC)</a>
                        </div>
                        <div class="details">
                            <div class="row">
                                <div class="col-6">
                                    <div class="course-list">
                                        <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8.5 9.5C11.5312 9.5 14 11.9688 14 15C14 15.5625 13.5312 16 13 16H1C0.4375 16 0 15.5625 0 15C0 11.9688 2.4375 9.5 5.5 9.5H8.5ZM1.5 14.5H12.4688C12.2188 12.5312 10.5312 11 8.5 11H5.5C3.4375 11 1.75 12.5312 1.5 14.5ZM7 8C4.78125 8 3 6.21875 3 4C3 1.8125 4.78125 0 7 0C9.1875 0 11 1.8125 11 4C11 6.21875 9.1875 8 7 8ZM7 1.5C5.59375 1.5 4.5 2.625 4.5 4C4.5 5.40625 5.59375 6.5 7 6.5C8.375 6.5 9.5 5.40625 9.5 4C9.5 2.625 8.375 1.5 7 1.5Z" fill="#2F57EF" />
                                        </svg>
                                        963 Students
                                    </div>
                                </div>
                            </div>
                            <h4 class="course-title mb-4"><a href="degree?program=GC">BS Computer Science <span style="font-size: 0.7em;">with specialization in</span> General Computing</a></h4>
                            <div class="row">
                                <div class="col-6">

                                </div>
                                <div class="col-6 align-self-center text-end">
                                    <a class="right-arrow-text fw-700 color-base" href="degree?program=GC">Enroll Now <i class="fa fa-arrow-right ms-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-9">

                    <div class="single-course-inner style-2">

                        <div class="thumb">
                            <img class="w-100" src="assets/img/about/AP3.webp" alt="img">
                            <a class="course-cat fw-500" href="degree?program=SE">BSSE</a>
                        </div>
                        <div class="details">
                            <div class="row">
                                <div class="col-6">
                                    <div class="course-list">
                                        <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8.5 9.5C11.5312 9.5 14 11.9688 14 15C14 15.5625 13.5312 16 13 16H1C0.4375 16 0 15.5625 0 15C0 11.9688 2.4375 9.5 5.5 9.5H8.5ZM1.5 14.5H12.4688C12.2188 12.5312 10.5312 11 8.5 11H5.5C3.4375 11 1.75 12.5312 1.5 14.5ZM7 8C4.78125 8 3 6.21875 3 4C3 1.8125 4.78125 0 7 0C9.1875 0 11 1.8125 11 4C11 6.21875 9.1875 8 7 8ZM7 1.5C5.59375 1.5 4.5 2.625 4.5 4C4.5 5.40625 5.59375 6.5 7 6.5C8.375 6.5 9.5 5.40625 9.5 4C9.5 2.625 8.375 1.5 7 1.5Z" fill="#2F57EF" />
                                        </svg>
                                        342 Students
                                    </div>
                                </div>
                            </div>
                            <h4 class="course-title  " style="margin-bottom:5.3rem"><a href="degree?program=SE">BS Software Engineering</a></h4>
                            <div class="row">
                                <div class="col-6">

                                </div>
                                <div class="col-6 align-self-center text-end"><a class="right-arrow-text fw-700 color-base" href="degree?program=SE">Enroll Now <i class="fa fa-arrow-right ms-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- course area end -->

    <!-- service-course-area start -->
    <div class="service-course-area pd-top-120 pd-bottom-90 position-relative">

        <img class="position_animate_img top_image_bounce position-bottom-left" src="assets/img/shape/4.png" alt="img">


        <div class="container service-areas">
            <div class="row">
                <div class="col-lg-12 mb-5 text-center">

                    <h1 class="title service-heading">Our Esteemed and Experienced Faculty</h1>
                </div>
            </div>
            <div class="container d-flex justify-content-center align-items-center">
                <div class="row mt-5 mt-lg-0 w-100">
                    <div class="col-xl-5 mb-md-0 mb-4">
                        <div class="bg-yellow p-2 border-radius-10 mb-xl-0 mb-2">
                            <div class="m-1 service-heading-1">
                                <h4 class="service-heading-2">Our Exceptional Educators</h4>
                                <ul class="p-0 m-2 single-check-inner mt-4 pt-2 pb-1">
                                    <li class="service-li">
                                        Dedicated mentors for student success
                                    </li>
                                    <li>
                                        Highly qualified and experienced professors
                                    </li>
                                    <li>
                                        Industry professionals with real-world expertise
                                    </li>
                                    <li class="mb-0">
                                        Innovative teaching and personalized guidance
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-7">
                        <div class="bg-relative service-course-thumb">
                            <img class="border-radius-5 top_image_bounce responsive-img service-img" src="assets/img/about/5.png" alt="img">

                            <!--<img style="margin-top: 45px;" class="shape_img left_image_bounce" src="assets/img/shape/4.png" alt="img">-->
                            <img class="border-radius-10 w-100" src="assets/img/about/Faculty2.webp" alt="img">
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- service-course-area end -->

    <!-- parse-option-area start -->
    <div class="parse-option-area pd-top-120 position-relative parse-img">
        <!--<img class="position_animate_img top_image_bounce position-top-right" alt="image">-->
        <div class="container">
            <div class="row parse-top">
                <div class="col-xl-12 col-lg-12 text-center parse-bottom">
                    <div class="section-title mb-0 mb-lg-5 pb-2">
                        <h6 class="sub-title">Choose your first step towards success</h6>
                        <h2 class="title title-h1 parse-heading">Why BIIT?</h2>
                    </div>
                </div>
            </div>
            <div class="parse-option box-shadow border-radius-40 overflow-hidden bg-white mt-5 mt-lg-0">
                <div class="row">
                    <div class="col-lg-6 min-height-350 parse-img-1"></div>
                    <div class="col-lg-6">
                        <div class="p-xxl-5 p-4">
                            <div class="media pt-lg-4">
                                <div class="media-left me-3">
                                </div>
                                <div class="media-body">
                                    <h5>Modern Learning Environment</h5>
                                    <p class="text-justify">Up-to-date classrooms equipped with the latest technology<br />
                                        Air-conditioned labs and classrooms for a comfortable learning experience </p>
                                </div>
                            </div>
                            <div class="media mt-4 pt-xl-3">
                                <div class="media-left me-3">
                                </div>
                                <div class="media-body">
                                    <h5>Comprehensive Facilities</h5>
                                    <p class="text-justify">Fully-equipped computer labs with advanced resources<br />
                                        Conveniently located near the metro for easy accessibility </p>
                                </div>
                            </div>
                            <div class="media mt-4 pt-xl-3 pb-lg-4">
                                <div class="media-left me-3">
                                </div>
                                <div class="media-body">
                                    <h5>Holistic Student Experience</h5>
                                    <p class="text-justify">Diverse extracurricular activities enhance student life by offering opportunities for personal growth, skill development, and social interaction beyond academic pursuits.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- parse-option-area end -->


    <!-- future generations start -->
    <div class="future-generations pd-top-115 position-relative">
        <!--<img class="position_animate_img top_image_bounce position-top-right" alt="image">-->
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-7 future-top">
                    <div class="section-title text-center">

                        <h2 class="title title-h1 future-heading">BIIT's Societies</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="future-generations-inner color-light-pink mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="left-content future-top-1">
                                    <div class="thumb mb-4 pb-2">
                                        <img src="assets/img/icon/dld.png" alt="img" class="future-img">

                                    </div>
                                    <div class="details">
                                        <h5 class="mb-3">BIIT DLD Society</h5>
                                        <p class="content mb-4">Driving progress of Digital Systems through research, and practical application.</p>
                                        <a class="right-arrow-text fw-600" href="Society?society=dld">Read More <i class="fa fa-arrow-right ms-2"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end align-self-end">
                                <div class="thumb future-right">
                                    <img src="assets/img/about/DLDF1.webp" alt="img" class="future-img-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="future-generations-inner color-light-blue mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="left-content">
                                    <div class="thumb mb-4 pb-2">
                                        <img src="assets/img/icon/cultural.png" alt="Logo" class="future-img-2">

                                    </div>
                                    <div class="details">
                                        <h5 class="mb-3">BIIT Cultural Society</h5>
                                        <p class="content mb-4">Embracing the cultural heritage through engaging events, and performances.</p>
                                        <a class="right-arrow-text fw-600" href="Society?society=culture">Read More <i class="fa fa-arrow-right ms-2"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end align-self-end">
                                <div class="thumb future-right-1">
                                    <img src="assets/img/about/CF1.webp" alt="img" class="future-img-3">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 ">
                    <div class="future-generations-inner color-light-yellow mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="left-content" class="future-top-2">
                                    <div class="thumb mb-4 pb-2">
                                        <img src="assets/img/icon/ps1.png" alt="Logo" class="future-img-4">
                                    </div>
                                    <div class="details">
                                        <h5 class="mb-3">BIIT Programming Society</h5>
                                        <p class="content mb-4">Uniting enthusiasts and experts alike to explore the endless possibilities of code.</p>
                                        <a class="right-arrow-text fw-600" href="Society?society=program">Read More <i class="fa fa-arrow-right ms-2"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end align-self-end">
                                <div class="thumb future-right-2">
                                    <img src="assets/img/about/PSFT3.webp" alt="img" class="future-img-5">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="future-generations-inner color-light-purple mb-5">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="left-content">
                                    <div class="thumb mb-5 pb-1 mt-2">
                                        <img src="assets/img/icon/Se.png" alt="Logo" class="future-img-6">

                                    </div>
                                    <div class="details">
                                        <h5 class="mb-3">BIIT Software Engineering Society</h5>
                                        <p class="content mb-4">Empowering software engineers to be equipped with the skills, mindset, and development.</p>
                                        <a class="right-arrow-text fw-600" href="Society?society=software">Read More <i class="fa fa-arrow-right ms-2"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end align-self-end">
                                <div class="thumb future-right-3">
                                    <img src="assets/img/about/SES2.1.webp" alt="img" class="future-img-7">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- future generations end -->

    <!--Video Area start-->
    <div class="section video-areas">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-9 videos-style">
                    <h2 class="title title-h1">A Tour of BIIT</h2>
                </div>
            </div>
        </div>
        <div class="video-area bg-cover pd-top-120 video-url">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-9 video-areas-style">
                        <div class="thumb video-2-thumb bg-relative border-radius-5 overflow-hidden video-layout">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/1y9zCCVZWqI?si=2BTSw-84OuSykINe" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--Video Area End-->

    <!--Events Section Start-->
    <div class="container py-5 event-areas">
        <h2 class="text-center mt-4 title-h1">News and Events</h2>
        <div class="row">
            <!-- Events Column -->
            <div class="col-lg-6 col-md-12 event-bot mb-md-0 mb-5 custom-bottom-event">
                <div class="events-box mb-4 event-height">
                    <div class="events-post event-bor">
                        <div class="event-inner-content event-top">
                            <div class="top-part d-flex align-items-center">
                                <div class="date-holder mr-2">
                                    <div class="date">
                                        <span class="date-day span-1">14</span><br>
                                        <span class="date-month span-2">Aug</span>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="event-meta mb-1">
                                        <span class="event-meta-piece start-time"><i class="material-icons event-li">access_time</i> 10:00 am - 2:00 pm</span>
                                    </div>
                                    <h2 class="article"><a href="News?Article=1">Independence Day Celebration</a></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="events-box mb-4 event-wid">
                    <div class="events-post event-sol">
                        <div class="event-inner-content event-top-1">
                            <div class="top-part d-flex align-items-center">
                                <div class="date-holder mr-2 event-height-1">
                                    <div class="date">
                                        <span class="date-day span-3">23</span><br>
                                        <span class="date-month span-4">March</span>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="event-meta mb-1">
                                        <span class="event-meta-piece start-time"><i class="material-icons event-li-1">access_time</i> 8:00 am - 2:00 pm</span>
                                    </div>
                                    <h2 class="article"><a href="News?Article=2">Pakistan Day Celebration</a></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- Third Event -->
                <div class="events-box mb-4 third-event">
                    <div class="events-post third-style">
                        <div class="event-inner-content third-top">
                            <div class="top-part d-flex align-items-center">
                                <div class="date-holder mr-2">
                                    <div class="date">
                                        <span class="date-day third-date">10</span><br>
                                        <span class="date-month third-mon">Jan</span>
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="event-meta mb-1">
                                        <span class="event-meta-piece start-time"><i class="material-icons third-li">access_time</i> 10:00 am - 2:00 pm</span>
                                    </div>
                                    <h2 class="article"><a href="News?Article=4">Innovative DLD Exhibition</a></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Images Column -->
            <div class="col-lg-6 col-md-12 img-column">
                <div class="slider img-size"> <!-- Adjust height and margin-top here -->
                    <div class="my-image d-flex align-items-center justify-content-center w-100 h-100">
                        <img src="assets/img/PHOTO.webp" alt="img" class="img-fluid position-absolute last-img-1">
                        <img src="assets/img/image.webp" alt="img" class="img-fluid position-absolute last-img-2">
                        <img src="assets/img/PHOTO3.webp" alt="img" class="img-fluid position-absolute last-img-3">
                    </div>
                </div>
            </div>
        </div>
    </div>







    <a href="https://wa.me/+923360572652" class="whatsapp-icon" target="_blank" title="Chat with us on WhatsApp">
        <img src="assets1/icons/whatsapp1.png" alt="WhatsApp">
    </a>

    <style>
    @media (max-width: 991px) {
        .row>* {
            justify-content: center;
            flex-shrink: 0;
            width: 100%;
            max-width: 100%;
            padding-right: calc(var(--bs-gutter-x)* .5);
            padding-left: calc(var(--bs-gutter-x)* .5);
            margin-top: var(--bs-gutter-y);
        }

    }


    .widget-recent-post table tbody tr:hover a {
        color: gold;
    }

    .whatsapp-btn {
        color: green;
        background-color: white;
        border-color: green;
        border-radius: 20px;
        min-height: 70px;
        width: 300px;
        transition: background-color 0.3s, color 0.3s;
    }

    .whatsapp-btn:hover {
        background-color: azure;
        color: white;
    }

    .whatsapp-btn img {
        transition: filter 0.3s;
    }

    .white-icon {
        color: white;
    }

    .enhanced-logo img {
        width: 150px;
        height: auto;
    }

    .apply-now-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        font-size: 16px;
        white-space: nowrap;
        min-width: 120px;
        height: 40px;
        line-height: 1;
    }

    .btn:hover,
    .btn-base:hover,
    .bg-base-9:hover {
        color: inherit;
        background-color: inherit;
    }

    @media (max-width: 768px) {
        .whatsapp-btn {
            margin-top: -20px;
            color: green;
            background-color: white;
            border-color: green;
            border-radius: 20px;
            min-height: 70px;
            width: 300px;
            transition: background-color 0.3s, color 0.3s;
        }

        .footer-subscribe .footer-subscribe-inner h2 {
            color: #fff;
            font-size: 25px;
            margin-bottom: -5px;
        }

        .apply-now-btn {
            font-size: 14px;
            padding: 8px 16px;
        }

        .footer-area {
            padding-left: 10px;
            padding-right: 10px;
        }

        .custom-container-footer {
            padding-left: 10px !important;
            padding-right: 10px !important;
        }

        .widget_about .details {
            text-align: center !important;
        }

        .widget_nav_menu {
            text-align: center !important;
        }

        .widget_contact {
            text-align: center !important;
        }

        .whatsapp-btn p {
            font-size: 18px;
            /* Adjust font size for smaller screens */
        }
    }

    .list-unstyled {
        padding: 0;
        list-style: none;
    }

    .list-unstyled li {
        margin-bottom: 10px;
    }

    .list-unstyled li a {
        text-decoration: none;
        color: white;
    }

    .list-unstyled li a:hover {
        color: gold;
    }

    .social-media {
        list-style: none;
        padding: 0;
        display: flex;
        gap: 0px;
    }




    .social-media a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: lightblue;
        transition: transform 0.3s ease, border 0.3s ease;
        border: none;
        /* Ensure no border is shown initially */
        transform: scale(1);
    }

    .social-media a:hover {
        border: 2px solid white;
        /* Avoid padding to keep the icon centered */
        transform: scale(1.2);
        /* Adjust this value to control the growth */
    }
    @media screen and (max-width: 600px) {
        .widget .details{
            height: 80px !important;
        }
        
    }
  
</style>





<footer class="footer-area pt-0 bg-cover pd-top-90" style="background-image: url('./assets/img/bg/footer.png'); width:auto;">
    <div class="footer-subscribe">

    </div>
    <div class="container pt-5 pb-4" >
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="widget widget_about text-center text-md-start">
                    <div class="thumb Logo mb-3">
                        <img src="assets/img/about/BIIT_logo.png" alt="img" style="width: 120px; height: auto;">
                    </div>
                    <div class="details" style="text-align: left;">
                        <ul class="social-media d-flex justify-content-center justify-content-md-start">
                            <li class="me-3">
                                <a class="text-white" href="https://www.facebook.com/BIITOfficial/" target="_blank" style="background-color: #3b5998;">
                                    <i class="fab fa-facebook-f" style="color: white;"></i>
                                </a>
                            </li>

                            <li class="me-3">
                                <a class="text-white" href="https://www.instagram.com/biitofficial/" target="_blank" style="background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); border-radius: 50%; ">
                                    <i class="fab fa-instagram" style="color: white;"></i>
                                </a>
                            </li>

                            <li>
                                <a class="text-white" href="https://www.youtube.com/@biitofficial/" target="_blank" style="background-color: #FF0000; ">
                                    <i class="fab fa-youtube" style="color: white;"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="widget widget_nav_menu text-center text-md-start">
                    <h3 class="widget-title" style="text-align: left; margin-top:10px;">All Links</h3>

                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="About-Us"><i style="color: white;" class="fas fa-arrow-right me-1"></i> About us</a></li>
                        <li class="mb-2"><a href="admission"><i style="color: white;" class="fas fa-arrow-right me-1"></i> Admissions</a></li>
                        <li class="mb-2"><a href="degree"><i style="color: white;" class="fas fa-arrow-right me-1"></i> Academic Programs</a></li>
                        <li><a href="Contact-Us"><i style="color: white;" class="fas fa-arrow-right me-1"></i> Contact us</a></li>

                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="widget widget-recent-post text-center text-md-start">
                    <h3 class="widget-title" style="text-align: left; margin-top:10px;">Contact Info</h3>
                    <table style="border-collapse: collapse; width: 100%; border:none; margin-top:-8px">
                        <tbody>
                            <tr>
                                <td style="border: none; padding: 8px;">
                                    <i style="color: white;" class="fas fa-map-marker-alt"></i>
                                </td>
                                <td style="color: white; border: none; padding: 8px; text-align:left">
                                    <a href="https://www.google.com/maps/search/?api=1&query=106-A%2F1+Murree+Rd%2C+Block+A+Satellite+Town+Rawalpindi%2C+Pakistan" target="_blank" style="color: white; text-decoration: none;"
                                        onmouseover="this.style.color='gold';"
                                        onmouseout="this.style.color='white';">
                                        106-A/1 Murree Rd, Block A Satellite Town Rawalpindi, Pakistan
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none; padding: 8px;">
                                    <i style="color: white; margin-right: 8px;" class="fas fa-phone-alt"></i>
                                </td>
                                <td style="color: white; border: none; padding: 8px;text-align:left">
                                    <a href="tel:+923360572652" style="color: white; text-decoration: none;"
                                        onmouseover="this.style.color='gold';"
                                        onmouseout="this.style.color='white';">
                                        (+92) 336-0572652
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none; padding: 8px;">
                                    <i style="color: white; margin-right: 8px;" class="fas fa-envelope"></i>
                                </td>
                                <td style="color: white; border: none; padding: 8px;text-align:left">
                                    <a href="mailto:admissions@biit.edu.pk" style="color: white; text-decoration: none;"
                                        onmouseover="this.style.color='gold';"
                                        onmouseout="this.style.color='white';">
                                        admissions@biit.edu.pk
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</footer>


<script>
document.addEventListener("DOMContentLoaded", function () {
  const imgs = document.querySelectorAll("img");

  imgs.forEach(img => {
    // Handle data-src and data-srcset first (for lazy-loaded images)
    ['src', 'data-src'].forEach(attr => {
      let src = img.getAttribute(attr);
      if (src && src.includes(".")) {
        let newSrc = src.replace(/(\.[a-zA-Z0-9]+)(\?.*)?$/, ".webp$2");
        img.setAttribute(attr, newSrc);
      }
    });

    ['srcset', 'data-srcset'].forEach(attr => {
      let srcset = img.getAttribute(attr);
      if (srcset) {
        let newSrcset = srcset.replace(/(\.[a-zA-Z0-9]+)(\s|,|$)/g, ".webp$2");
        img.setAttribute(attr, newSrcset);
      }
    });
  });
});
</script>
<script>
window.addEventListener("load", function () {
  document.querySelectorAll("img").forEach(img => {
    let src = img.getAttribute("src");
    if (src && src.includes(".") && !src.endsWith(".webp")) {
      let newSrc = src.replace(/(\.[a-zA-Z0-9]+)(\?.*)?$/, ".webp$2");
      img.setAttribute("src", newSrc);
      console.log("Converted:", newSrc);
    }
  });
});
</script>



<script src="assets/js/fontawesome.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/main.js"></script>





    <script>
        function hideLoader() {
            $('.preloader').fadeOut(100);
        }

        $(document).ready(function() {
            setTimeout(hideLoader, 200); // Hide the loader after 1 second
        });
        let slides = document.querySelectorAll('.slider img');
        let currentSlide = 0;

        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.style.opacity = (i === index) ? 1 : 0;
            });
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        setInterval(nextSlide, 3000); // Change slide every 5 seconds
        showSlide(currentSlide);
    </script>


    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>